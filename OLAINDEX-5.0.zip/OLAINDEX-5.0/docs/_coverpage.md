![logo](logo.svg)
# OLAINDEX

> ✨ Another OneDrive Directory Index.

* 简单而强大
* 多主题
* 基于 Laravel

[GitHub](https://github.com/WangNingkai/OLAINDEX/)
[演示地址](https://share.imwnk.cn/)

![color](#f0f0f0)
