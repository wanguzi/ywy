<div class="text-center">
    <a href="{{ $file['download'] }}" data-fancybox="image-list">
        <img src="{{ $file['thumb'] }}" alt="{{ $file['name'] }}" class="img-fluid">
    </a>
</div>
